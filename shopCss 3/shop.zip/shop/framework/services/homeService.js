define(["angular","framework/http"],function(angular,https){
	function homePage($q){
		https.call(this,$q);
	}
	homePage.prototype = new https();


	homePage.prototype.categoryData = function(){
		return this.doRequest({
			url:"/api/v1/accounts/1/stores/1/products?category=all&limit=10",
			method:"get"
		});
	}

	
	return homePage;
});