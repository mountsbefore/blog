define(["angular","framework/http"],function(angular,https){
	function accountsReq($q){
		https.call(this,$q);
	}
	accountsReq.prototype = new https();
	accountsReq.prototype.forLogon = function(data){
		return this.doRequest({
			url:"/api/v1/login",
			method:"post",
			data:data,
		});
	}


	// $.ajax({
	// 	url:"http://116.62.6.51:3000/api/v1/login",
	// 	method:"POST",
	// 	data:{
	// 		"username":"18717373045",
	// 		"password":"1234"
	// 	},
	// 	success:function(data){
	// 		console.log(data)
	// 	},
	// 	error:function(err){
	// 		console.log(err)
	// 	}





	return accountsReq;
});