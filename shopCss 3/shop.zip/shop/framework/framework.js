define(
	['angular',
	"ui-router",
	"amaze",
	"swiper",
	"framework/directive",
	"business/home/config",
	"business/brand/config",
	"business/shopping/config",
	"business/account/config",
	"business/productDetail/config"
	],
	function(angularl,uirouter,amaze,swiper,frwork,config){
	var con = ["$scope","$state","$rootScope",function($scope,$state,$rootScope){

	}];
	deps = ["ng",
	"ui.router",
	config.name
	];
	var frame =  angular.module("framework",deps);
	frame.controller("mycontroller",con);
	frame.config(function(){
	});
	// run
	frame.run(function($rootScope,$state){
		$rootScope.$on("$stateChangeSuccess",function(e,c,n){
			if ($rootScope.menuPstion[c.name]) {
				console.log($rootScope.menuPstion[c.name],"scroll...")
				$("body").animate({
					scrollTop:$rootScope.menuPstion[c.name]
				},1000);
			};
		});

		$rootScope.serviceAddress = "http://www.yiyunma.com"
		$rootScope.users = {};
		$rootScope.menuPstion = {};
		$rootScope.menuchangePosRem = {};
		$rootScope.shopListNum = {num:0};
		$rootScope.deatilFlag = false;
		$rootScope.currentMenu = 0; 

		$rootScope.scrollToZero = function(){
			$("body").animate({
				scrollTop:0
			},0);
		}
		$rootScope.curMenuDegist = function(pre,cur){
			$rootScope.menuchangePosRem[pre] = $("body").scrollTop();
			$rootScope.currentMenu = cur;
			// console.log(pre,$rootScope.menuchangePosRem[pre],cur,$rootScope.menuchangePosRem[cur])
			setTimeout(function(){
				$("body").animate({
						scrollTop:$rootScope.menuchangePosRem[cur] ||0
				},0);
			},100);
		}
		$rootScope.stateGoto = function(statusNum){
			var hashurl = window.location.hash.split("/");
			hashurl = hashurl[hashurl.length-1]
			$rootScope.menuPstion[hashurl] = $("body").scrollTop();
			$state.go("detail",{productId:statusNum});
		};
		$rootScope.historyBack = function(){
			window.history.back(-1);
		};


	});
	return frame;
});
