define(["ui-router","swiper","amaze"],function(router,Swiper,zmaze){
	var mod = angular.module("ui.router");
		// escape physic backbutton bug
		// var shopInc = new shopList($q);
		

	function newGuid(){
	    var guid = "";
	    for (var i = 1; i <= 32; i++){
	      var n = Math.floor(Math.random()*16.0).toString(16);
	      guid +=   n;
	      if((i==8)||(i==12)||(i==16)||(i==20))
	        guid += "-";
	    }
	    return guid;    
	}


	mod.directive("amSwiper",function(){
		return {
			restrict:"ECA",
			link:function(scope,element,attr){
				// console.log("swiper...")
				var swiper = new Swiper('.swiper-container', {
			        paginationClickable: true,
			        // Disable preloading of all images
			        preloadImages: true,
			        // Enable lazy loading
			        lazyLoading: true
		      });

			}
		}
	});


	mod.directive("amModalPlug",function(){
		return {
			restrict:"ECA",
			templateUrl:"framework/template/modal.html",
			scope:{
				options:"="
			},
			link:function(scope,element,attr){
				// scope.title = options.title;
				// scope.content = options.content;
				scope._id = newGuid();
				var id = "#" + scope._id;
				scope.options.showDialog = function(){

					$(id).modal({closeViaDimmer:false},"open")
				}
				scope.options.hideDialog = function(){
					$(id).modal("close")
				}
				scope.options.showDialogdwhite = function(){

					$(id).modal({"dimmer":false},"open")
				}


			}
		}
	});

	mod.directive("amSwiperPlug",function(){
		return {
			restrict:"ECA",
			templateUrl:"/framework/template/swiper.html",
			scope:{
				options:"="
			},
			link:function(scope,element,attr){
				scope.picArry = [];
				scope.$watchCollection("options",function(newone,oldone){
					// scope.options = [];
					// console.log(newone,"new")
					scope.picArry = [];
					// delete swiper;
					scope.picArry = newone;

					setTimeout(function(){
					var swiper = new Swiper(".swiper-container", {
						    nextButton: '.swiper-button-next',
					        prevButton: '.swiper-button-prev',
					        pagination: '.swiper-pagination',
					        paginationClickable: true,
					        // Disable preloading of all images
					        preloadImages: false,
					        // Enable lazy loading
					        lazyLoading: true,
							loop : true,
							autoplay: 3000,
			      		});
					},0);
										
				},true);
			}
		}
	});

	mod.directive("amCounts",function(){
		return {
			restrict:"ECA",
			scope:{
				production:"="
			},
			link:function(scope,element,attr){
				var parent = scope.$parent;
				scope.production.status = "pending"
				scope.production.productEdit = false;
				var initNum = scope.production.amount;
				scope.production.edit = function(num){
					scope.production.productEdit = !scope.production.productEdit;
					
					if (num) {
						// check num equal
						if (initNum != scope.production.amount) {
							var flag = parent.changebagListNum(scope.production.amount,scope.production.id)
							if (flag) {

							}else{
								scope.production.amount = initNum;
							};
							// save changed
							

						};
					};
				}

				scope.production.increase = function(){
					scope.production.amount++;
				}
				scope.production.reduce = function(){
					
					if (scope.production.amount == 1) {

					}else{
						scope.production.amount--;
					};
				}
				scope.production.changStatus = function(){
					if (scope.production.status == "pending") {
						scope.production.status = "done";
					}else{
						scope.production.status = "pending";
					};
				}
			}
		}
	});
	mod.directive("amStrickyDtv",function(){
		return {
			restrict:"ECA",
			scope:{
				num:"="
			},
			link:function(scope,element,attr){
				$(element[0]).sticky({
					top: scope.num || 0,
					animation:"slide-top"
				})

			}
		}
	});

	// mod.directive("amSwiperPlug",function(){
	// 	// restrict:"ECA",
	// 	// // templateUrl:"/framework/template/swiper.html",
	// 	// link:function(scope,element,attr){
	// 	// }
	// });
	// mod.directive("amIscroll",function(){
	// 	return {
	// 		restrict:"ECA",
	// 		link:function(scope,element,attr){
	// 			// myScroll = new IScroll('#wrapper', { scrollX: true, freeScroll: true });
	// 			myScroll = new IScroll(element[0], { scrollX: true, 
	// 				freeScroll: true,
	// 				bounce:true,
	// 				freeScroll:true,
	// 				 });

	// 		}
	// 	}
	// });
	

	// router.directive("btDialog",function(){
	// 	var config = {
	// 		restrict:"E",
	// 		transclude: true,
	// 		scope:{
	// 			options:"="
	// 		},
	// 		templateUrl:"/framework/template/dialog.html",
	// 		link:function(scope,element,attr){
				
	// 			scope._id = newGuid();
	// 			var id = "#" + scope._id;
	// 			scope.showDialog = function(){
	// 				$(id).modal("show")
	// 			}

	// 			scope.$watch("options",function(newValue,oldValue){
	// 				scope._title = newValue.titleName || '';
	// 				scope._btnSave = newValue.btnSaveName || "save";
	// 				scope._cancel = newValue.btnCancel || "";
	// 				scope._btnShowName = newValue.butShowName || "modal";
	// 				scope._displayNoBtn = newValue.displayNoBtn || "";
	// 				if (scope._displayNoBtn) {
	// 					$(id).modal("show");
	// 				};

	// 				$(id).on("show.bs.modal",function(){
	// 					if (typeof newValue.beforeShow == "function") {
	// 						newValue.beforeShow();
	// 					};
	// 				});
	// 				scope.save = function(){
	// 					if (newValue.afterShow && typeof newValue.afterShow == "function") {
	// 						newValue.afterShow();
	// 						$(id).modal("hide");
	// 					};
	// 				}

	// 			},true);
	// 		}
	// 	}
	// });

	return mod;
});