/**
 * Created by Administrator on 2016/12/7.
 */
define(["amaze"],function(){
    var ctrl = ["$scope",function($scope){
        $scope.name = "test";
    }];
    return ctrl;
});