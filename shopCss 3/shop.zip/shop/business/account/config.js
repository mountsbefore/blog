define(["angular","ui-router"],function(angular,uirouter){

	var config = ["$stateProvider","$urlRouterProvider","$controllerProvider",function($stateProvider,$urlRouterProvider,$controllerProvider){
		$stateProvider.state("accounts",{
			url:"/accounts",
			templateUrl:"./business/account/accounts/accounts.html",
			controller:"accounts.ctrl",
			resolve:{
				deps:function($q,$rootScope){
					var defered = $q.defer();
					var dependiences = ["./business/account/accounts/accounts"];
					require(dependiences,function(ctrl){
						$rootScope.$apply(function(){
							$controllerProvider.register("accounts.ctrl",ctrl);
							defered.resolve();
						});
					});
					return defered.promise;
				}
			}
		});
		$stateProvider.state("logon",{
			url:"/logon",
			templateUrl:"./business/account/logon/logon.html",
			controller:"logon.ctrl",
			resolve:{
				deps:function($q,$rootScope){
					var defered = $q.defer();
					var dependiences = ["./business/account/logon/logon"];
					require(dependiences,function(ctrl){
						$rootScope.$apply(function(){
							$controllerProvider.register("logon.ctrl",ctrl);
							defered.resolve();
						});
					});
					return defered.promise;
				}
			}
		});
		$stateProvider.state("pwdLogon",{
			url:"/pwdLogon",
			templateUrl:"./business/account/pwdLogon/pwdLogon.html",
			controller:"pwdLogon.ctrl",
			resolve:{
				deps:function($q,$rootScope){
					var defered = $q.defer();
					var dependiences = ["./business/account/pwdLogon/pwdLogon"];
					require(dependiences,function(ctrl){
						$rootScope.$apply(function(){
							$controllerProvider.register("pwdLogon.ctrl",ctrl);
							defered.resolve();
						});
					});
					return defered.promise;
				}
			}
		});
		$stateProvider.state("myOrder",{
			url:"/myOrder",
			params:{statusId:null},
			templateUrl:"./business/account/myOrder/myOrder.html",
			controller:"myOrder.ctrl",
			resolve:{
				deps:function($q,$rootScope){
					var defered = $q.defer();
					var dependiences = ["./business/account/myOrder/myOrder"];
					require(dependiences,function(ctrl){
						$rootScope.$apply(function(){
							$controllerProvider.register("myOrder.ctrl",ctrl);
							defered.resolve();
						});
					});
					return defered.promise;
				}
			},
		});
		$stateProvider.state("collect",{
			url:"/collect",
			params:{statusId:null},
			templateUrl:"./business/account/collect/collect.html",
			controller:"collect.ctrl",
			resolve:{
				deps:function($q,$rootScope){
					var defered = $q.defer();
					var dependiences = ["./business/account/collect/collect"];
					require(dependiences,function(ctrl){
						$rootScope.$apply(function(){
							$controllerProvider.register("collect.ctrl",ctrl);
							defered.resolve();
						});
					});
					return defered.promise;
				}
			},
		});

		$stateProvider.state("coupon",{
			url:"/coupon",
			params:{statusId:null},
			templateUrl:"./business/account/coupon/coupon.html",
			controller:"coupon.ctrl",
			resolve:{
				deps:function($q,$rootScope){
					var defered = $q.defer();
					var dependiences = ["./business/account/coupon/coupon"];
					require(dependiences,function(ctrl){
						$rootScope.$apply(function(){
							$controllerProvider.register("coupon.ctrl",ctrl);
							defered.resolve();
						});
					});
					return defered.promise;
				}
			},
		});

		$stateProvider.state("register",{
			url:"/register",
			params:{statusId:null},
			templateUrl:"./business/account/register/register.html",
			controller:"register.ctrl",
			resolve:{
				deps:function($q,$rootScope){
					var defered = $q.defer();
					var dependiences = ["./business/account/register/register"];
					require(dependiences,function(ctrl){
						$rootScope.$apply(function(){
							$controllerProvider.register("register.ctrl",ctrl);
							defered.resolve();
						});
					});
					return defered.promise;
				}
			},
		});

		
		
	}];
    var  mo = angular.module("ui.router");
    mo.config(config);
    return  mo;
});
