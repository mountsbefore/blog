/*
define(["amaze"],function(){
	var ctrl = ["$scope","$stateParams",function($scope,$stateParams){
		var id =  $stateParams.statusId;
		console.log($stateParams,"$stateParams....")
		console.log(id,"myordre.....")
	}];
	return ctrl;
});
*/

define(["amaze"],function(){
	var ctrl = ["$scope","$stateParams",function($scope,$stateParams){
		var id =  $stateParams.statusId;
		$scope.orderStatus = $stateParams.statusId;
		console.log($stateParams,"$stateParams....")
		console.log($stateParams.statusId,"$stateParams....")

		console.log(id,"myordre.....")
	}];
	return ctrl;
});