define(["amaze"],function (){
	var ctrl = ["$scope","$http","$state",function($scope,$http,$state){
		$scope.changedPage2logon = function(){
			$state.go("logon");
		}
		$scope.changedPage2pss = function(){
			$state.go("pwdLogon");
		}
		$scope.changedPage2orderStatus = function(statusNum){
			// $scope.orderStatus = status;
			// $scope.pageStatus = "orderStatus";
			$state.go("myOrder",{statusId:statusNum})
		}

		function init(){
			console.log("init...");
			$.ajax({
			    url: 'http://139.196.205.1:3000/api/v1/accounts/1',
			    method:"DELETE",
			    headers: { 'Authorization': 'Token token="FrINlwOKma7Rkl/jHCmI4WGhUIvgqTE+Tt4t9OslNtQuV5mW/XzOPrjbMuR1GR33V8cHRzVdSKHJrZffC3sR4Q==", mobile_number="18717373045"' ,
			'Content-Type': 'application/json'},
			    success:function(data){
			    	console.log(data)
			    },
			    error:function(data){
			    	console.log(data)
			    }
			});
		}
		// init();

		$scope.toGOCollect=function(){
			$state.go("collect");
		}

		$scope.toCoupon=function(){
			$state.go("coupon");
		}
		function init(){
			if (!$scope.users.owner_id) {
				// alert("请先登录");
				$scope.changedPage2logon();
				return;
			};

		}
		init();

	}];
	return ctrl;
});