define(["amaze"],function(){
	var ctrl = ["$scope",function($scope){

	}]
	return ctrl;
});