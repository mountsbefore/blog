/**
 * Created by Administrator on 2016/12/4.
 */
define(["amaze"],function(){
    var ctrl = ["$scope",function($scope){

    }]
    return ctrl;
});