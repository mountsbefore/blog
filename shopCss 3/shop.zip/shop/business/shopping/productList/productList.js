define(["amaze","framework/services/shoppingService","wx"],function (amaze,shopList,wx){
	var ctrl = ["$scope","$state","$q","orderList",function($scope,$state,$q,orderList){

		var shopInc = new shopList($q);
		console.log($scope.users.owner_id,"owner_id...");
		$scope.getAllPrice = function(){
			var allPrice = 0 ;
			for (var i = 0; i < $scope.pdtList.length; i++) {
				if ($scope.pdtList[i].status == "done") {
					allPrice += ($scope.pdtList[i].product.real_price * $scope.pdtList[i].amount)
				};
			};
			$scope.allPrice = allPrice;
		}
		

		// paymentpage
		$scope.pageStatus = "orderPage"
		
		$scope.changedPage2payment = function(){
			// $scope.pageStatus = "paymentpage"
			var arr = [];
			for (var i = 0; i < $scope.pdtList.length; i++) {
				if ($scope.pdtList[i].status == "done") {
					arr.push($scope.pdtList[i]);
				};
			};
			orderList.allPrice = $scope.allPrice;
			orderList.setList(arr);
			if (arr.length) {
				$state.go("payment");
			}else{
				alert("请选择您要购买的产品");
			};
		}
		$scope.changebagListNum = function(num,productid){

			var data = {
			    "cart": {
			        "amount": num
			    }
			}
			
			shopInc.changedProductNumber(data,{headers:$scope.users.setheaders},productid).then(function(data){
				console.log(data,212121)
				return true;
			},function(err){
				return false;
				console.log(err)
			});
		}

		$scope.deleteProductNumber = function(num){
			
			shopInc.deleteProductNumber({headers:$scope.users.setheaders},num).then(function(data){
				console.log(data,"deletesucce.....")
				init();
			},function(){

			});

		}
		$scope.gotoLogon = function(){
			$state.go("logon");
		}
	
		function init(){
			if (!$scope.users.owner_id) {
				// alert("请先登录");
				return;
			};
			shopInc.getAllOrderList($scope.users.owner_id).then(function(data){
				console.log(data,"getAllOrderList....")
				$scope.pdtList = data.data
				$scope.shopListNum.num = $scope.pdtList.length;
				// $scope.$apply();
			},function(err){
				console.log(err,"shopInc...err....")
			});
		}
		init();
	}];
	return ctrl;
});