define(["amaze","wx"],function (amaze,wx){
	var ctrl = ["$scope","$state","orderList",function($scope,$state,orderList){
		console.log(orderList);

		$scope.displayOrderList = orderList.getList();
		$scope.allPrice = orderList.allPrice;
		console.log($scope.displayOrderList,"orderlist.....")


		$scope.addOrChangeAddr = function(){
			$state.go("receiveAddr");
		}

		$scope.toPay=function(){
			$state.go("payPage");
		}

		function init(){
			console.log("pamyment...page...")
		}
	}]
	return ctrl;
});
